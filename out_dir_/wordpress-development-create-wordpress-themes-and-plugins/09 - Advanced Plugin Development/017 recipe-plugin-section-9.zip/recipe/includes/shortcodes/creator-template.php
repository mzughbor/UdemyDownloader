<div id="recipe-status"></div>
<form id="recipe-form">
  <div class="form-group">
    <label>Title</label>
    <input type="text" class="form-control" id="r_inputTitle">
  </div>
  CONTENT_EDITOR
  <div class="form-group">
    <button type="submit" class="btn btn-primary">Submit Recipe</button>
  </div>
</form>